package com.driverpro.app;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import android.webkit.JsPromptResult;
import android.webkit.WebResourceRequest;
import android.view.ViewGroup;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int GPS_PERMISSION_REQUEST = 2604;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 2605;
    private WebView webView;
    private boolean permissionRequestPending = false;
    private boolean startAfterPermission = false;
    private boolean receiverRegistered = false;

    private final BroadcastReceiver gpsReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (webView == null || intent == null) return;
            if (GpsTrackingService.ACTION_LOCATION.equals(intent.getAction())) {
                double lat = intent.getDoubleExtra(GpsTrackingService.EXTRA_LAT, 0);
                double lon = intent.getDoubleExtra(GpsTrackingService.EXTRA_LON, 0);
                float accuracy = intent.getFloatExtra(GpsTrackingService.EXTRA_ACCURACY, 999f);
                long time = intent.getLongExtra(GpsTrackingService.EXTRA_TIME, 0);
                sendLocation(lat, lon, accuracy, time);
            } else if (GpsTrackingService.ACTION_STATUS.equals(intent.getAction())) {
                sendGpsStatus(intent.getStringExtra(GpsTrackingService.EXTRA_STATUS), intent.getStringExtra(GpsTrackingService.EXTRA_MESSAGE));
            }
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        webView.setBackgroundColor(0xFF050A12);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setMessage(message).setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel()).show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this).setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel()).show();
                return true;
            }
            @Override public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
                final android.widget.EditText input = new android.widget.EditText(MainActivity.this);
                input.setText(defaultValue == null ? "" : defaultValue);
                new android.app.AlertDialog.Builder(MainActivity.this).setMessage(message).setView(input)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm(input.getText().toString()))
                        .setNegativeButton(android.R.string.cancel, (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel()).show();
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equalsIgnoreCase(uri.getScheme()) && "android_asset".equals(uri.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                return true;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("file:///android_asset/")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
                return true;
            }
        });
        webView.addJavascriptInterface(new GpsBridge(), "DriverProGps");
        setContentView(webView, new ViewGroup.LayoutParams(-1, -1));
        registerGpsReceiver();
        webView.loadUrl("file:///android_asset/index.html");
        requestNotificationPermissionIfNeeded();
    }

    private void registerGpsReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(GpsTrackingService.ACTION_LOCATION);
        filter.addAction(GpsTrackingService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(gpsReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(gpsReceiver, filter);
        receiverRegistered = true;
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    private class GpsBridge {
        // Durable key/value storage for app records and preferences. commit() confirms disk write.
        @JavascriptInterface public String getLocalValue(String key) {
            if (key == null || key.length() > 100) return null;
            return getSharedPreferences("driverpro_app_data", MODE_PRIVATE).getString(key, null);
        }
        @JavascriptInterface public boolean setLocalValue(String key, String value) {
            if (key == null || key.length() > 100 || value == null || value.length() > 10_000_000) return false;
            return getSharedPreferences("driverpro_app_data", MODE_PRIVATE).edit().putString(key, value).commit();
        }
        @JavascriptInterface public void removeLocalValue(String key) {
            if (key == null || key.length() > 100) return;
            getSharedPreferences("driverpro_app_data", MODE_PRIVATE).edit().remove(key).commit();
        }
        @JavascriptInterface public void startGps() { runOnUiThread(() -> requestGpsPermissionAndStart()); }
        @JavascriptInterface public void stopGps() { runOnUiThread(() -> stopGpsService()); }
        @JavascriptInterface public String getUpdatesSince(long timestamp) { return loadNativePointsSince(timestamp); }
        @JavascriptInterface public boolean isTrackingServiceRunning() { return GpsTrackingService.trackingActive; }
        @JavascriptInterface public boolean openNavigation(double lat, double lon, String label) {
            if (!validCoordinates(lat, lon)) return false;
            runOnUiThread(() -> {
                String destination = lat + "," + lon;
                try {
                    Intent maps = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(destination) + "&mode=d"));
                    maps.setPackage("com.google.android.apps.maps");
                    startActivity(maps);
                    return;
                } catch (Exception ignored) { }
                try {
                    String query = destination + (label == null || label.trim().isEmpty() ? "" : "(" + label.trim() + ")");
                    Intent geo = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + destination + "?q=" + Uri.encode(query)));
                    startActivity(geo);
                    return;
                } catch (Exception ignored) { }
                try {
                    Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(destination) + "&travelmode=driving"));
                    startActivity(browser);
                } catch (Exception ignored) { }
            });
            return true;
        }
        @JavascriptInterface public boolean setArrivalTarget(double lat, double lon, float radius, String label) {
            if (!validCoordinates(lat, lon)) return false;
            float safeRadius = Math.max(50f, Math.min(2000f, radius));
            getSharedPreferences("driverpro_gps_native", MODE_PRIVATE).edit()
                    .putBoolean("arrivalActive", true).putBoolean("arrivalNotified", false)
                    .putFloat("arrivalLat", (float) lat).putFloat("arrivalLon", (float) lon)
                    .putFloat("arrivalRadius", safeRadius).putString("arrivalLabel", label == null ? "الوجهة" : label).apply();
            return GpsTrackingService.trackingActive;
        }
        @JavascriptInterface public boolean wasArrivalNotified() {
            return getSharedPreferences("driverpro_gps_native", MODE_PRIVATE).getBoolean("arrivalNotified", false);
        }
        @JavascriptInterface public void clearArrivalTarget() {
            getSharedPreferences("driverpro_gps_native", MODE_PRIVATE).edit().putBoolean("arrivalActive", false).putBoolean("arrivalNotified", false).apply();
        }
        private boolean validCoordinates(double lat, double lon) {
            return !Double.isNaN(lat) && !Double.isInfinite(lat) && !Double.isNaN(lon) && !Double.isInfinite(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;
        }
    }

    private boolean hasFineLocationPermission() {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    private boolean hasCoarseLocationPermission() {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestGpsPermissionAndStart() {
        if (!hasFineLocationPermission() && !hasCoarseLocationPermission()) {
            if (Build.VERSION.SDK_INT >= 23 && !permissionRequestPending) {
                permissionRequestPending = true;
                startAfterPermission = true;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, GPS_PERMISSION_REQUEST);
            }
            return;
        }
        startGpsService();
    }

    private void startGpsService() {
        try {
            getSharedPreferences("driverpro_gps_native", MODE_PRIVATE).edit().putBoolean("tracking", true).apply();
            Intent service = new Intent(this, GpsTrackingService.class);
            service.setAction(GpsTrackingService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        } catch (Exception e) {
            sendGpsStatus("error", "تعذر تشغيل خدمة GPS في الخلفية. تحقق من صلاحيات الموقع.");
        }
    }

    private void stopGpsService() {
        getSharedPreferences("driverpro_gps_native", MODE_PRIVATE).edit().putBoolean("tracking", false).apply();
        Intent service = new Intent(this, GpsTrackingService.class);
        service.setAction(GpsTrackingService.ACTION_STOP);
        try { startService(service); } catch (Exception ignored) { stopService(new Intent(this, GpsTrackingService.class)); }
        sendGpsStatus("stopped", "تم إيقاف تتبع GPS.");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == GPS_PERMISSION_REQUEST) {
            permissionRequestPending = false;
            boolean granted = hasFineLocationPermission() || hasCoarseLocationPermission();
            if (granted && startAfterPermission) startGpsService();
            else sendGpsStatus("denied", "لم يتم منح إذن الموقع. يمكنك تفعيله من إعدادات الهاتف.");
            startAfterPermission = false;
        }
    }

    private String loadNativePointsSince(long timestamp) {
        JSONArray result = new JSONArray();
        try {
            JSONArray points = new JSONArray(getSharedPreferences("driverpro_gps_native", MODE_PRIVATE).getString("points", "[]"));
            for (int i = 0; i < points.length(); i++) {
                JSONObject p = points.getJSONObject(i);
                if (p.optLong("time", 0) > timestamp) result.put(p);
            }
        } catch (Exception ignored) { }
        return result.toString();
    }

    private void sendLocation(double lat, double lon, float accuracy, long time) {
        if (webView == null) return;
        String js = "window.onNativeLocation && window.onNativeLocation(" + lat + "," + lon + "," + accuracy + "," + time + ");";
        webView.evaluateJavascript(js, null);
    }

    private void sendGpsStatus(String status, String message) {
        if (webView == null) return;
        try {
            String js = "window.onNativeGpsStatus && window.onNativeGpsStatus(" + JSONObject.quote(status == null ? "" : status) + "," + JSONObject.quote(message == null ? "" : message) + ");";
            webView.evaluateJavascript(js, null);
        } catch (Exception ignored) { }
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.postDelayed(() -> webView.evaluateJavascript("window.syncNativeGps && window.syncNativeGps();", null), 700);
    }

    @Override protected void onDestroy() {
        if (receiverRegistered) { try { unregisterReceiver(gpsReceiver); } catch (Exception ignored) { } }
        if (webView != null) {
            webView.removeJavascriptInterface("DriverProGps");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
